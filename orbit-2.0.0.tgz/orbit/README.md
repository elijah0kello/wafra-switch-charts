# Orbit — Helm chart

Admin UI and API adapter for a Mojaloop classic switch, packaged to the Switch
App Contract.

- **Exposure scope:** `internal`. See [Identity and threat model](#identity-and-threat-model)
  for why this is load-bearing rather than a preference.
- **Identity:** contract §7 shape **(a) self-contained**.
- **Scaling:** the API adapter is single-replica by design. The UI scales freely.

---

## Contents

| Resource | Name | Notes |
|---|---|---|
| Deployment | `<release>-ui` | Angular SPA on nginx, stateless, `RollingUpdate` |
| Deployment | `<release>-api` | Express + SQLite, `Recreate` (see [Scaling](#scaling)) |
| Service | `<release>-ui` | ClusterIP — the one thing routed to, via `exposure` |
| Service | `<release>-api` | ClusterIP — reached only by the UI's nginx |
| ConfigMap | `<release>-ui-nginx` | The nginx server block (§3) |
| PersistentVolumeClaim | `<release>-api-data` | `helm.sh/resource-policy: keep` |
| ServiceAccount + Role + RoleBinding | `<release>-api[-fees]` | Only when `feeManagement.enabled` |

No `Ingress`, `Gateway`, `VirtualService`, `HTTPRoute` or `LoadBalancer`
Service is created. The chart declares intent in `exposure`; `switchctl`
renders the routing (§4).

---

## Building

Two images, two contexts. Every path each Dockerfile `COPY`s exists relative to
the context stated here. Run both from the repository root:

```bash
# API adapter
docker build -f wafra-admin-api/Dockerfile \
  -t wafra-admin-api:2.0.0 ./wafra-admin-api

# Admin UI
docker build -f admin-ui/Dockerfile.wafra \
  -t wafra-admin-ui:2.0.0 ./admin-ui
```

Push both to the switch's registry and deploy by digest:

```bash
docker buildx build --platform linux/amd64 \
  -f wafra-admin-api/Dockerfile \
  -t zot.infra.example.com/wafra-admin-api:2.0.0 --push ./wafra-admin-api
```

The cluster nodes are `linux/amd64`. A default build on an Apple Silicon machine
produces an arm64-only image and the kubelet fails with `no match for platform
in manifest` — use `buildx --platform linux/amd64` for anything pushed.

---

## Values

Anything marked **required** has no working default. Leaving one unset does not
fall back to a guess: `helm template` fails, or the adapter prints the missing
variable names and exits non-zero so the pod crash-loops visibly (§3).

### Images

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `adminUi.image.registry`<br>`apiAdapter.image.registry` | no | Prefixed to `repository` when set. Point at the switch's Zot, e.g. `zot.infra.example.com`. Empty means Docker Hub. | Wrong host → `ImagePullBackOff` |
| `adminUi.image.repository`<br>`apiAdapter.image.repository` | yes (defaulted) | Image name without registry. | `ImagePullBackOff` |
| `adminUi.image.tag`<br>`apiAdapter.image.tag` | yes, unless `digest` set | Full three-component version. Never `latest` (§2). | Template fails if both tag and digest are empty |
| `adminUi.image.digest`<br>`apiAdapter.image.digest` | no | `sha256:…`. **Wins over `tag`.** Preferred — `switchctl` records the resolved digest and reports drift. | — |
| `adminUi.image.pullPolicy`<br>`apiAdapter.image.pullPolicy` | no | Defaults `IfNotPresent`. **Never set `Never`** — Argo CD cannot side-load images. | `Never` + absent image → pod never starts |

### Admin UI

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `adminUi.replicas` | no (2) | Stateless; scale freely. | — |
| `adminUi.resources` | no | Requests and limits. | Too low → OOMKill or throttling |
| `adminUi.service.port` | no (80) | Service port. Must match `exposure[].port`. | Gateway routes to a closed port |
| `adminUi.containerPort` | no (4200) | Port nginx listens on. **Must equal `adminUi.nginx.listenPort`.** | Probes and Service fail; pod never becomes ready |
| `adminUi.probes.*` | no | Paths and timings. `/healthz` is served by nginx itself, so readiness does not depend on the API. | Wrong path → permanent `NotReady` |
| `adminUi.nginx.listenPort` | no (4200) | See `containerPort`. | As above |
| `adminUi.nginx.healthPath` | no (`/healthz`) | Probe endpoint. Change both this and `probes.*` together. | Permanent `NotReady` |
| `adminUi.nginx.clientMaxBodySize` | no (12m) | Upload ceiling — the liquidity check accepts a bank statement. | Too low → 413 on statement upload |
| `adminUi.nginx.proxyReadTimeout` | no (60s) | Upstream read timeout. | Too low → 504 on slow settlement reports |

### API adapter — switch service URLs

All four are **required** and must be *complete* URLs including scheme and
port. The app never assembles `<service>.<namespace>.svc.cluster.local` itself
(§1), so a bare hostname will not work.

| Value | Meaning | If wrong |
|---|---|---|
| `apiAdapter.env.CENTRAL_LEDGER_URL` | Central Ledger base URL | Participants, accounts and funds screens return 500 |
| `apiAdapter.env.CENTRAL_SETTLEMENT_URL` | Central Settlement base URL | Settlement windows and matrices empty or 500 |
| `apiAdapter.env.ALS_ADMIN_URL` | Account Lookup **admin** API | Oracle management fails |
| `apiAdapter.env.ALS_MSISDN_ORACLE_URL` | MSISDN oracle. Distinct from the admin API above. | Party association read/write fails |

Point them at a *different* cluster and every screen still renders — it just
shows another switch's data. There is no way for the app to detect this, which
is exactly why none of these has a default.

### API adapter — storage

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `apiAdapter.persistence.enabled` | no (true) | **Keep true.** False means every operator account, role, dispute, adjustment and journalled transfer is lost on restart. | Silent total data loss on reschedule |
| `apiAdapter.persistence.storageClass` | **yes** | A `ReadWriteOnce` class that exists on the cluster (`local-path` on k3s, `gp3` on EKS). | Non-existent class → PVC `Pending` forever, pod never schedules |
| `apiAdapter.persistence.size` | no (2Gi) | Grows with the transfer journal, which never expires. | Full volume → SQLite writes fail |
| `apiAdapter.persistence.accessMode` | no (RWO) | Must stay `ReadWriteOnce`. | — |
| `apiAdapter.persistence.mountPath` | no (`/data`) | Also passed as `DATA_DIR`, so app and volume always agree. | — |

### API adapter — secret

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `apiAdapter.jwtSecret.secretName` | no | Secret `switchctl` provisions from Vault. | Missing Secret → pod stuck `CreateContainerConfigError` |
| `apiAdapter.jwtSecret.key` | no (`JWT_SECRET`) | Key within that Secret. | As above |

There is deliberately no value that carries the secret itself. Values are
pushed to a git repo Argo CD reads (§8); see `switchapp.yaml` `secrets`.

### API adapter — transfer journal (optional)

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `apiAdapter.kafka.brokers` | no | Comma-separated bootstrap addresses. **Empty means the consumer never starts** and the app stays healthy — the transfers and quotes views are simply empty. | Wrong address → journal silently empty; check the pod log for the connect warning |
| `apiAdapter.kafka.topics.*` | no | Topic names. Defaults match a stock Mojaloop deployment. | Wrong topic → transfers never appear |

### API adapter — CORS

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `apiAdapter.cors.allowedOrigins` | no (`[]`) | Explicit origin list. Empty means same-origin only, which is correct — the UI is served through its own nginx. | Adding `"*"` on a credentialed API is unsafe; list real origins instead |

### API adapter — fee management (optional, off)

Off by default. With it off the adapter makes no Kubernetes API calls and its
ServiceAccount token is not mounted at all.

| Value | Required | Meaning | If wrong |
|---|---|---|---|
| `apiAdapter.feeManagement.enabled` | no (false) | Master switch. While false, `/fees/*` returns `501` with an explanation. | — |
| `apiAdapter.feeManagement.switchNamespace` | **when enabled** | Namespace the switch core runs in. | Template fails |
| `apiAdapter.feeManagement.rulesConfigMap` | **when enabled** | The switch's settlement rules ConfigMap. | Template fails |
| `apiAdapter.feeManagement.rulesDeployment` | **when enabled** | Deployment restarted after a rate change. | Template fails |
| `apiAdapter.feeManagement.feeConfigConfigMap` | no | ConfigMap holding the current rate. **This app patches it; it does not create it.** Must already exist. | Rate change returns 500 |
| `apiAdapter.feeManagement.defaultRate` | no (0.006) | Rate reported when the ConfigMap is unreadable. | — |
| `apiAdapter.feeManagement.createRbac` | no (false) | Render Role + RoleBinding into `switchNamespace`. Only works if whoever applies the chart may create RBAC there; otherwise grant out of band and leave false. | Sync fails with a permissions error |

### Exposure

| Value | Meaning |
|---|---|
| `exposure[].name` | Stable identifier used in generated resource names |
| `exposure[].service` | Logical service name; matched against the `switchctl.io/exposure-name` label |
| `exposure[].port` | Must match `adminUi.service.port` |
| `exposure[].scope` | `internal` — see below. Do not change to `public`. |
| `exposure[].hostname` | Supplied at deploy time. Empty means not exposed. |
| `exposure[].paths` | Prefixes routed to the service |

---

## DNS

| Hostname | VIP | Record | Notes |
|---|---|---|---|
| value of `exposure[0].hostname`<br>e.g. `orbit.internal.example.com` | **Internal VIP** | `A` | The only record orbit needs. The internal VIP is never DNAT'd, so this name does not resolve to anything reachable from the internet. |

Orbit needs **no public DNS record**. If you find yourself creating one,
something has gone wrong — see below.

The adapter is not exposed and needs no record; the UI reaches it by Service
name inside the namespace.

---

## Identity and threat model

This chart takes contract §7 shape **(a): self-contained.**

**Why not Keycloak.** Orbit owns its users, roles, privileges and maker-checker
approval chains, and those records are load-bearing throughout its data model:
every dispute, adjustment and finalization request is attributed to an orbit
user id, and the approval rules compare an approver against the original
submitter to enforce that nobody approves their own work. Delegating
authentication to an external provider means migrating that identity model, not
setting a config value. The contract explicitly scopes this work to deployment
and configuration, so shape (a) is the honest choice. Shape (b) remains a clean
future path — the `identity` block in `switchapp.yaml` is present and empty.

**What orbit does enforce.**

- Sessions are JWTs signed with a key sourced from Vault, never a value.
- Every endpoint except `GET /health` and `POST /auth_n/token` requires a
  verified bearer token. Signature, expiry and issuer are checked server-side.
- Role and privilege are read from the *verified* token, never from a request
  header — a header is only trustworthy if nothing can reach the app except the
  proxy that sets it, and on this switch that is not guaranteed.
- Mutating fee endpoints additionally require the `fees.write` privilege.
- The first administrator password is generated at first boot, printed once,
  and must be changed at first login. Nothing is seeded into the image.

**What orbit relies on the platform for.** Orbit authenticates operators but
does not defend against internet-scale credential attacks: there is no rate
limiting, no lockout, and no MFA. `scope: internal` is therefore part of the
control, not a convenience — the internal VIP is never DNAT'd, so the login
form is unreachable from the internet regardless of DNS. **Moving this to
`scope: public` would expose an unrated login form to the internet.** Do not.

Note also that an Istio `AuthorizationPolicy` restricting traffic by source IP
is silently inert in ambient mode — accepted, reported healthy, not enforced.
Nothing here relies on one.

---

## Scaling

| Component | Replicas | Why |
|---|---|---|
| `admin-ui` | any | Stateless; serves static assets and proxies. |
| `api-adapter` | **1 only** | All state is SQLite in `orbit.db` on a `ReadWriteOnce` volume. A second replica cannot mount it, and if it could, concurrent writers would corrupt the database. |

The adapter Deployment uses `strategy: Recreate` for the same reason — a
`RollingUpdate` deadlocks, because the new pod waits for a volume the old pod
has not released.

Raising `apiAdapter.replicas` above 1 will not work and risks data loss. If
orbit ever needs horizontal scale, that is a migration off SQLite, not a values
change.

---

## Deploying

```bash
helm upgrade --install orbit ./helm/orbit \
  --namespace "$ORBIT_NAMESPACE" \
  --create-namespace \
  -f my-values.yaml
```

The namespace is supplied here and nowhere else — it appears in no template,
helper or default (§1).

---

## Verification

None of this uses `port-forward`. Substitute your namespace for `$NS`.

**1. Both workloads rolled out**

```bash
kubectl -n "$NS" rollout status deploy/orbit-api --timeout=120s
kubectl -n "$NS" rollout status deploy/orbit-ui  --timeout=120s
```

**2. Configuration actually landed** — proves no value fell back to a guess:

```bash
kubectl -n "$NS" exec deploy/orbit-api -- printenv \
  CENTRAL_LEDGER_URL CENTRAL_SETTLEMENT_URL ALS_ADMIN_URL ALS_MSISDN_ORACLE_URL DATA_DIR
```

**3. The adapter is healthy and reachable by its Service name**, from a
throwaway pod in the same namespace — this is the exact path the UI's nginx
uses:

```bash
kubectl -n "$NS" run orbit-verify --rm -it --restart=Never \
  --image=curlimages/curl:8.10.1 -- \
  curl -sS http://orbit-api:3000/health
# expect: {"status":"ok"}
```

**4. Authorization is enforced** — an unauthenticated call must be refused:

```bash
kubectl -n "$NS" run orbit-verify --rm -it --restart=Never \
  --image=curlimages/curl:8.10.1 -- \
  curl -sS -o /dev/null -w '%{http_code}\n' http://orbit-api:3000/participants
# expect: 401
```

**5. The UI serves and proxies correctly** — the check that would have caught
the baked-in-nginx bug, since it exercises UI → nginx → adapter:

```bash
kubectl -n "$NS" run orbit-verify --rm -it --restart=Never \
  --image=curlimages/curl:8.10.1 -- sh -c '
    echo -n "SPA:   "; curl -sS -o /dev/null -w "%{http_code}\n" http://orbit-ui/
    echo -n "proxy: "; curl -sS -o /dev/null -w "%{http_code}\n" http://orbit-ui/_participants/participants
  '
# expect: SPA: 200, proxy: 401  (401 proves it reached the adapter — a 502 means it did not)
```

**6. Retrieve the first-run administrator password** (first install only):

```bash
kubectl -n "$NS" logs deploy/orbit-api | grep -A4 'FIRST-RUN'
```

**7. Through the gateway**, once `switchctl` has rendered routing and the DNS A
record exists. Run from a host on the internal network:

```bash
curl -sS -o /dev/null -w '%{http_code}\n' "https://$ORBIT_HOSTNAME/"
# expect: 200
```

---

## Contract feedback

Three places where orbit did not fit the contract cleanly. The first is a
genuine gap; the other two are constraints worth stating.

### 1. `requires.rbac` has no vocabulary for a cross-namespace grant

§6 offers `namespaced` or `cluster`. Orbit's optional fee-management feature
needs neither.

Interchange fee rates are enforced by a rules script the switch's settlement
handler loads from a ConfigMap. Changing a rate means rewriting that ConfigMap
and restarting the handler that reads it. Both objects belong to the **switch**,
so the grant cannot live in orbit's own namespace — but `cluster` would be a
wild over-grant for what is, concretely, two named ConfigMaps and one named
Deployment. It is also exactly the shape §8 warns about: the version of this
code we are replacing paired a cluster-wide `configmaps: patch` with an
unauthenticated write endpoint.

`switchapp.yaml` proposes a third scope, `foreign`, naming the namespace by
`valueKey` so `switchctl` can create a `Role` and `RoleBinding` there and refuse
when the operator has not authorised it:

```yaml
rbac:
  scope: namespaced
  foreign:
    - namespaceValueKey: apiAdapter.feeManagement.switchNamespace
      enabledValueKey: apiAdapter.feeManagement.enabled
      justification: …
      rules: [ … resourceNames-scoped, get + patch only … ]
```

This generalises past orbit: any app that manages a switch component it does not
own has the same shape. Without it, the honest options are to declare `cluster`
and over-grant, or drop the feature. We have defaulted the feature **off** so
the base install is genuinely `namespaced`, and scoped the grant by
`resourceNames` with no `list` or `watch`.

Note that this is also the one place a namespace appears in the chart. It is a
*foreign* namespace supplied as a value, never orbit's own, so we read it as
consistent with §1's intent — but §1 as written says "no namespace may appear
anywhere in your chart", and this is worth an explicit carve-out in the text.

### 2. §5 "declare `replicas` as a value" sits awkwardly with a single-writer app

`replicas` is a value, as required, and `values.yaml` says in a comment that it
must stay 1. But a value that must never be changed is a trap: nothing stops
`--set apiAdapter.replicas=3`, and the failure mode is data corruption rather
than a clean error. A contract-level way to declare "this workload is
single-writer" — which `switchctl` could refuse to override — would be more
robust than a comment. The `strategy: Recreate` requirement travels with it and
has the same problem.

### 3. §3 and §6 `optional: true` pull in opposite directions for Kafka

§3 says no environment-specific value may have a working default. §6 lets a
dependency be `optional`, meaning the app must start and stay healthy without
it. For `KAFKA_BROKERS` these meet: absent has to mean *disabled*, which is a
working default in §3's sense.

We resolved it by treating absent as an explicit, logged choice — the adapter
warns at startup that the journal is off and the transfers views will be empty,
rather than either crashing or staying quiet. That seems like the right reading,
but the contract could say so directly: for an `optional` dependency, absent
means disabled and the app must say so in its log.
