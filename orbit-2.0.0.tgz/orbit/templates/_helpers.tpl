{{/*
Switch App Contract §1: no namespace appears anywhere in this chart. Every
resource lands in .Release.Namespace, chosen by switchctl at deploy time.
There is deliberately no "orbit.namespace" helper — if you find yourself
wanting one, the value you actually need is a complete URL (§3).
*/}}

{{- define "orbit.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "orbit.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := include "orbit.name" . }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Component names. The nginx ConfigMap resolves the API by this Service name,
     unqualified, so it resolves within whatever namespace we are deployed to. */}}
{{- define "orbit.adminUi.fullname" -}}
{{- printf "%s-ui" (include "orbit.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "orbit.apiAdapter.fullname" -}}
{{- printf "%s-api" (include "orbit.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "orbit.serviceAccountName" -}}
{{- printf "%s-api" (include "orbit.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "orbit.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ include "orbit.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: orbit
{{- end }}

{{/*
Render an image reference.

Contract §2: every image reference must be resolvable to a digest, and the
registry must be repointable at the switch's own registry (Zot) without
editing the chart. When .digest is set it wins over .tag.

Usage: {{ include "orbit.image" .Values.adminUi.image }}
*/}}
{{- define "orbit.image" -}}
{{- $repo := .repository -}}
{{- if .registry -}}
{{- $repo = printf "%s/%s" (trimSuffix "/" .registry) .repository -}}
{{- end -}}
{{- if .digest -}}
{{- printf "%s@%s" $repo .digest -}}
{{- else -}}
{{- printf "%s:%s" $repo (required "image.tag is required when image.digest is not set" .tag) -}}
{{- end -}}
{{- end }}
